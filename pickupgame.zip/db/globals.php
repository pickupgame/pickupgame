<?php

// // aws
$GLOBALS['host'] = "pickupgameapp.cmkzt5hznaki.us-east-1.rds.amazonaws.com:3306";
$GLOBALS['db_username'] = 'cis435pickupgame';
$GLOBALS['db_password'] = '12345678';
$GLOBALS['db_name'] = 'pickupgamedatabase'; 

// //local
// $GLOBALS['host'] = "127.0.0.1";
// $GLOBALS['db_username'] = 'root';
// $GLOBALS['db_password'] = '';
// $GLOBALS['db_name'] = 'pickupgame'; 
?>